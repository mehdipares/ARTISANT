function Footer() {
    return (
      <footer className="bg-light text-center py-3 mt-5">
        <p>© 2025 Trouve ton artisan - Antenne de Lyon</p>
        <p><a href="/mentions-legales">Mentions légales</a></p>
      </footer>
    );
  }
  export default Footer;
  