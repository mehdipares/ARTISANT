function ArtisanDetail() {
    return <div className="container py-5"><h1>Fiche d’un artisan</h1></div>;
  }
  export default ArtisanDetail;
  