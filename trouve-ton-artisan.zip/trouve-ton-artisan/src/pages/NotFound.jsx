function NotFound() {
    return (
      <div className="container py-5 text-center">
        <h1>404</h1>
        <p>Cette page n'existe pas</p>
      </div>
    );
  }
  export default NotFound;
  