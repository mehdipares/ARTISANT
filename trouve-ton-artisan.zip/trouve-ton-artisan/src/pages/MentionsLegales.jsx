function MentionsLegales() {
    return <div className="container py-5"><h1>Mentions légales</h1></div>;
  }
  export default MentionsLegales;
  